## "Cambridge" Stereo Algorithms

The Cambridge programs are a diverse set of delay and stereo-widening effects.
They are based on multi-tap delay lines which are scaled or modulated
differently in each program to achieve different effects.
